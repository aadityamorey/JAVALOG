# SLF4J Logback Tutorial

Article link : https://www.mkyong.com/logging/slf4j-logback-tutorial/

