# Apache Log4j 2 Tutorial

Article link : https://www.mkyong.com/logging/apache-log4j-2-tutorials/